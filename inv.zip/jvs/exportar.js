function exportToCSV() {
    // Redirecciona a un archivo PHP que manejará la exportación
    window.location.href = './php/export.php';
  }